// let hidePhone = +996555123123;

function hide(number) {
  const removeNumber = number.slice(0, -2) + "xx";
  return removeNumber;
}
console.log(hide("+996555123123"));

function charCount(word, letter) {
  const lowerWord = word.toLowerCase();
  const lowerLetter = letter.toLowerCase();
  return lowerWord.split("").filter((c) => c === lowerLetter).length;
}
console.log(charCount("Abrakadabra", "A"));
console.log(charCount("hello", "l"));
